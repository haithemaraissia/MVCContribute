namespace Web.Models
{
    public enum NumberOfTypeEnum
    {
        One,
        Two,
        Three,
        Four
    }
}