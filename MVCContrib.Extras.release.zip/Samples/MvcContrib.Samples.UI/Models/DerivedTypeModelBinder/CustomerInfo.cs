﻿using System.Collections.Generic;

namespace MvcContrib.Samples.UI.Models.DerivedTypeModelBinder
{
	public class CustomerInfo
	{
		public List<IContent> Contents { get; set; }
	}
}