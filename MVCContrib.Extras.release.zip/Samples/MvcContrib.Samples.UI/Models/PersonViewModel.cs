namespace MvcContrib.Samples.UI.Models
{
	public class PersonViewModel
	{
		public Person Person;
		public string EmployerName;
	}
}