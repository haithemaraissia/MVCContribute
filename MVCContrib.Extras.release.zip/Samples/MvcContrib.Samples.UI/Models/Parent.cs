namespace MvcContrib.Samples.UI.Models
{
	public class Parent
	{
		public string Name { get; set; }
	}
}