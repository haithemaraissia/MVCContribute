using System;

namespace MvcContrib.Samples.UI.Models
{
	public class Company
	{
		public Guid Id { get; set; }
		public string Name { get; set; }
	}
}