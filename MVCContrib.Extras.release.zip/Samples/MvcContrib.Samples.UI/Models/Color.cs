namespace MvcContrib.Samples.UI.Models
{
	public enum Color
	{
		Red,
		Blue,
		Green
	}
}