using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: AssemblyProduct("MvcContrib.IncludeHandling")]
[assembly: CLSCompliant(false)]
