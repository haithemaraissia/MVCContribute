﻿if (console && console.log) {
	console.log("hi");
}
