﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("MvcTestingFramework")]
[assembly: InternalsVisibleTo("MvcContrib.UnitTests")]