﻿using System.Reflection;

[assembly: AssemblyTitle("CommandProcessor.IntegrationTests")]
