﻿using System.Reflection;

[assembly: AssemblyTitle("CommandProcessor.UnitTests")]
