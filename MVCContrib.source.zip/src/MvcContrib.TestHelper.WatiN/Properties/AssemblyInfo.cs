﻿using System.Reflection;

[assembly: AssemblyTitle("UITestHelper.WatiN")]
