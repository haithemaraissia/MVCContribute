namespace MvcContrib
{
	public static class HttpHeaders
	{
		public const string AcceptEncoding = "Accept-Encoding";
		public const string ContentEncoding = "Content-Encoding";
		public const string ContentLength = "Content-Length";
	}
}