namespace MvcContrib
{
	public static class MimeTypes
	{
		public const string ApplicationJavaScript = "application/javascript";
		public const string TextCss = "text/css";
	}
}