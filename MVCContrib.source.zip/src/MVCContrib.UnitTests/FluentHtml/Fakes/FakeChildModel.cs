namespace MvcContrib.UnitTests.FluentHtml.Fakes
{
	public class FakeChildModel
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public decimal Balance { get; set; }
	}
}
