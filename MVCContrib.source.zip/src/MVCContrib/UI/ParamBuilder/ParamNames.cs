using MvcContrib.UI.ReturnUrl;

namespace MvcContrib.UI.ParamBuilder
{
	public class ParamNames
	{
		public const string ReturnUrl = ReturnUrlManager.ParameterName;
	}
}