namespace MvcContrib.UI.InputBuilder.Views
{
	public class Partial
	{
		public const string Boolean = "Boolean";
		public const string DateTime = "DateTime";
		public const string Enum = "Enum";
		public const string Form = "Form";
		public const string Guid = "Guid";
		public const string Int32 = "Int32";
		public const string MultilineText = "MultilineText";
		public const string RadioButtons = "RadioButtons";
		public const string ReadOnly = "ReadOnly";
		public const string String = "String";
		public const string Submit = "Submit";
	}
}