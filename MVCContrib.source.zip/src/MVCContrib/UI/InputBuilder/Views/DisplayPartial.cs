namespace MvcContrib.UI.InputBuilder.Views
{
	public class DisplayPartial
	{
		public const string Label = "DisplayLabel";
		public const string Inline = "DisplayInline";
		public const string Paragraph = "DisplayParagraph";
	}
}