using System;

namespace MvcContrib.UI.InputBuilder.Attributes
{
	public class NoDeleteAttribute : Attribute
	{
	}
}