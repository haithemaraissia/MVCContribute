using System;

namespace MvcContrib.UI.InputBuilder.Attributes
{
	public class CanDeleteAllAttribute : Attribute
	{
	}
}