using System;

namespace MvcContrib.UI.InputBuilder.Attributes
{
	public class NoAddAttribute : Attribute
	{
	}
}