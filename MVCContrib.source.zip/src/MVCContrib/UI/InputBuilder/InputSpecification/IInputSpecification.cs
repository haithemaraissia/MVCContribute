namespace MvcContrib.UI.InputBuilder.InputSpecification
{
	public interface IInputSpecification<T>
	{
		T Model { get; }
	}
}