namespace MvcContrib.SimplyRestful
{
	public enum RestfulGetAction
	{
		Show = 1,
		Index = 16,
		New = 32,
		Edit = 64,
		Delete = 128
	}
}
