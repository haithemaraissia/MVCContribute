﻿namespace MvcContrib.Sorting
{
	public enum SortDirection
	{
		Ascending, Descending
	}
}